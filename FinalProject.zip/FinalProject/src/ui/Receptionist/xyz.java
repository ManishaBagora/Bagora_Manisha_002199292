package ui.Receptionist;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Manisha Bagora
 */
public class xyz {

    
    private PatientCatalog patientCatalog;

    public xyz() {
        patientCatalog = new PatientCatalog();
    }

    

    public PatientCatalog getPatientCatalog() {
        return patientCatalog;
    }

    public void setPatientCatalog(PatientCatalog patientCatalog) {
        this.patientCatalog = patientCatalog;
    }

    

}

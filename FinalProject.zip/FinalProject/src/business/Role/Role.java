/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business.Role;

import business.Business;
import business.Organization.Organization;
import business.UserAccount.UserAccount;
import javax.swing.JPanel;

/**
 *
 * @author Manisha Bagora
 */
public abstract class Role {

    public enum RoleType {
        Admin("Admin"),
        Admin1("Admin1"),
        Doctor("Doctor"),
        LabAssistant("Lab Assistant"),
        Boston("Boston"),
        CA("CA"),
        Newyork("Newyork"),
        Pharmacy("Pharmacy"),
        MR("MR"),
        Receptionist("Receptionist"),
        AdminE("AdminE");

        public static RoleType getAdminE() {
            return AdminE;
        }

        public static RoleType getAdmin1() {
            return Admin1;
        }

       

        public static RoleType getPharmacy() {
            return Pharmacy;
        }

        public static RoleType getReceptionist() {
            return Receptionist;
        }

        public static RoleType getMR() {
            return MR;
        }
        

        public static RoleType getNewyork() {
            return Newyork;
        }

        public void setValue(String value) {
            this.value = value;
        }

        private String value;

        public static RoleType getAdmin() {
            return Admin;
        }

        public static RoleType getDoctor() {
            return Doctor;
        }

        public static RoleType getLabAssistant() {
            return LabAssistant;
        }

        public static RoleType getBoston() {
            return Boston;
        }

        public static RoleType getCA() {
            return CA;
        }

        private RoleType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public RoleType type;

    public abstract JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Business business);

    @Override
    public String toString() {
        return (type != null) ? this.type.getValue() : this.getClass().getName();
    }

}

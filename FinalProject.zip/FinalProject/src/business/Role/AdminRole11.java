/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business.Role;

import business.Business;
import business.Enterprize.AdminEnterprize;
import business.Enterprize.BostonEnterprize;

import business.Organization.Organization;
import business.UserAccount.UserAccount;

import javax.swing.JPanel;
import ui.BostonWorkAreaJPanel;


/**
 *
 * @author Manisha Bagora
 */
public class AdminRole11 extends Role {
BostonEnterprize enterprize;
    public AdminRole11() {
        this.type = RoleType.Admin1;
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Business business) {
        this.type = RoleType.Admin1;
        return new BostonWorkAreaJPanel(userProcessContainer, account, (BostonEnterprize) enterprize, business);
    }

}

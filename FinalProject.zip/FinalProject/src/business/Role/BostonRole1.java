/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business.Role;

import business.Business;
import business.Enterprize.BostonEnterprize;

import business.Organization.Organization;
import business.UserAccount.UserAccount;
import ui.DoctorRole.DoctorWorkAreaJPanel;
import javax.swing.JPanel;
import ui.BostonWorkAreaJPanel;

/**
 *
 * @author Manisha Bagora
 */
public class BostonRole1 extends Role {
BostonEnterprize enterprize;
    public BostonRole1() {
        this.type = RoleType.Boston;
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Business business) {
        this.type = RoleType.Boston;
        return new BostonWorkAreaJPanel(userProcessContainer, account, (BostonEnterprize) enterprize, business);
    }

}

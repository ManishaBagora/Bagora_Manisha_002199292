/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package business.Enterprize;




import business.Enterprize.Enterprize.Type;

import java.util.ArrayList;

/**
 *
 * @author Manisha Bagora
 */
public class EnterprizeDirectory {
    
    private ArrayList<Enterprize> enterprizeList;

    public EnterprizeDirectory() {
        enterprizeList = new ArrayList<>();
    }

    public ArrayList<Enterprize> getenterprizeList() {
        return enterprizeList;
    }
    
    public Enterprize createEnterprize(Type type){
        Enterprize enterprize = null;
        if (type.getValue().equals(Type.Boston.getValue())){
            enterprize = new BostonEnterprize();
            enterprizeList.add(enterprize);
        }
        else if (type.getValue().equals(Type.CA.getValue())){
            enterprize = new CAEnterprize();
            enterprizeList.add(enterprize);
        }
        else if (type.getValue().equals(Type.Newyork.getValue())){
            enterprize = new NewyorkEnterprize();
            enterprizeList.add(enterprize);
        }
          else if (type.getValue().equals(Type.Admin11.getValue())){
            enterprize = new AdminEnterprize();
            enterprizeList.add(enterprize);
        }
        else if (type.getValue().equals(Type.AdminE.getValue())){
            enterprize = new AdminEEnterprize();
            enterprizeList.add(enterprize);
        }
        return enterprize;
    }
}